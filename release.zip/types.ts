export interface IConfig {
    db_host: string | undefined,
    db_user: string | undefined,
    db_password: string | undefined,
    db_database: string | undefined,
    db_port: string | undefined
}