INSERT INTO users(
    username,
    password,
    name,
    surname,
    phone_number,
    email_address
)
VALUES(?, ?, ?, ?, ?, ?)