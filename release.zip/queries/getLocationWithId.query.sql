SELECT * from locations
WHERE id = ?