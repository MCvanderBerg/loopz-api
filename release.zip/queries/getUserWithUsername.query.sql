SELECT *
FROM users
WHERE users.username = ?