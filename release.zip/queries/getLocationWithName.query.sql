SELECT * FROM locations
WHERE name = ?