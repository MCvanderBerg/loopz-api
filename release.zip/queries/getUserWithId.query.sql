SELECT *
FROM users
WHERE users.id = ?